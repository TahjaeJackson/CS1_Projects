# Name: Tahjae Jackson
# Date: November 13, 2021
# Purpose: to create vertex class

class Vertex:
    def __init__(self, vertex, adjacent, text):
        self.vertex = vertex
        self.adjacent = adjacent
        self.text = text

