# Name: Tahjae Jackson
# Date: October 22, 2021
# Purpose: Class used to design the system of bodies for the solar system


from Body import *


class System:
    def __init__(self, body_list):
        self.body_list = body_list


    def update(self, timestep):
        for i in range(len(self.body_list)):

            ax = 0
            ay = 0

            if i != 0 :
                ax = -0.0028
                ay = -0.0028

            self.body_list[i].update_position(timestep)

            self.body_list[i].update_velocity(ax, ay, timestep)

    def draw(self, cx, cy, pixels_per_metre):
        for i in range(len(self.body_list)):
            self.body_list[i].draw(cx - self.body_list[i].x * pixels_per_metre, cy - self.body_list[i].y * pixels_per_metre, pixels_per_metre)
